from django.contrib import admin
from django.urls import include, path
from . import views
from measurements.views import health_check

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index),
    path('health/', health_check),
    path('', include('measurements.urls')),
    path('', include('variables.urls')),
]
