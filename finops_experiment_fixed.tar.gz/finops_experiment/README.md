# FinOps Experiment - Guía de despliegue en AWS

## Variables de entorno requeridas (ECS / Docker)

| Variable | Descripción | Ejemplo |
|---|---|---|
| DB_HOST | Endpoint RDS | `biteco-finops-db.xxx.us-east-1.rds.amazonaws.com` |
| DB_NAME | Nombre de la DB | `biteco_db` |
| DB_USER | Usuario DB | `biteco_admin` |
| DB_PASSWORD | Contraseña DB | (desde SSM) |
| REDIS_HOST | Endpoint ElastiCache | `biteco-finops-redis.xxx.cache.amazonaws.com` |
| SECRET_KEY | Django secret key | (string aleatorio) |
| DEBUG | Modo debug | `False` |

## Endpoints de la API

| Endpoint | Método | Descripción | ASR |
|---|---|---|---|
| `/health/` | GET | Health check del ALB | - |
| `/api/health/` | GET | Health check detallado | - |
| `/api/reports/?company=X` | GET | Reporte de costos (con cache Redis) | Latencia 100ms |
| `/api/costs/` | POST | Crear registro de costo | Escalabilidad |

## Despliegue local con Docker

```bash
docker build -t finops-app .
docker run -p 8000:8000 \
  -e DB_HOST=localhost \
  -e DB_NAME=finops \
  -e DB_USER=postgres \
  -e DB_PASSWORD=postgres \
  finops-app
```

## Subir imagen a ECR

```bash
# 1. Crear repositorio en ECR
aws ecr create-repository --repository-name biteco-django --region us-east-1

# 2. Login a ECR
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin \
  <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com

# 3. Build y push
docker build -t biteco-django .
docker tag biteco-django:latest \
  <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/biteco-django:latest
docker push \
  <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/biteco-django:latest
```

## Pruebas JMeter

Los archivos de prueba están en la carpeta `Jmeter-test/`.

- **ASR Latencia**: `GET /api/reports/?company=Acme Corp` → debe responder < 100ms
- **ASR Escalabilidad**: `POST /api/costs/` con 5000-15000 usuarios concurrentes → debe responder < 2000ms
